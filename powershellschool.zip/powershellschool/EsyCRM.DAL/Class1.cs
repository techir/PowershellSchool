﻿using System;

namespace EsyCRM.DAL
{
    public class Class1
    {
    }
}
