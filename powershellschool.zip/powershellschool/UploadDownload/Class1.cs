﻿using System;

namespace UploadDownload
{
    public class Class1
    {
    }
}
