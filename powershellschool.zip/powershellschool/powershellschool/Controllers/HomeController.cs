﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using powershellschool.Models;
using System.Net.Mail;
using System.IO;
using Microsoft.AspNetCore.Http;
using powershellschool.Models.Home2;
using Microsoft.Extensions.FileProviders;

namespace powershellschool.Controllers
{


    public class HomeController : Controller
    {
        private readonly IFileProvider fileProvider;
        private readonly PhysicalFileProvider phyFileProvider = new PhysicalFileProvider(@"C:\webfiles\scripts");

        public HomeController(IFileProvider fileProvider)
        {
            this.fileProvider = fileProvider;
        }


        [HttpGet]
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Contact(ContactViewModel vm)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    MailMessage msz = new MailMessage();
                    msz.From = new MailAddress(vm.Email);//Email which you are getting 
                                                         //from contact us page 
                    msz.To.Add("altugyildirim1993@gmail.com,hakkiogretmen@gmail.com");//Where mail will be sent 
                    msz.Subject = vm.Subject;
                    msz.Body = vm.Message;
                    SmtpClient smtp = new SmtpClient();

                    smtp.Host = "smtp.gmail.com";

                    smtp.Port = 587;

                    smtp.Credentials = new System.Net.NetworkCredential
                    ("denemealtug@gmail.com", "");

                    smtp.EnableSsl = true;

                    smtp.Send(msz);

                    ModelState.Clear();
                    ViewBag.Message = "Bizimle iletişime geçtiğiniz için teşekkür ederiz. ";
                }
                catch (Exception ex)
                {
                    ModelState.Clear();
                    ViewBag.Message = $" Bir hata oluştu! {ex.Message}";
                }
            }

            return View();
        }

        public IActionResult Scriptler()
        {
            var model = new FilesViewModel();
            foreach (var item in this.phyFileProvider.GetDirectoryContents(""))
            {
                model.Files.Add(
                    new FileDetails { Name = item.Name, Path = item.PhysicalPath });
            }
            TempData["debug"] = model.Files[0].ToString();
            return View(model);
        }

       
        public IActionResult Blog()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Forum(CheckExistingMemberLoginInfo logincheck)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    MailMessage msz = new MailMessage();
                    msz.From = new MailAddress(logincheck.Email);//Email which you are getting 
                                                                 //from contact us page 
                    msz.To.Add("altugyildirim1993@gmail.com,hakkiogretmen@gmail.com");//Where mail will be sent 
                    msz.Subject = "Kullanıcı Girişi hk.";
                    msz.Body = logincheck.Email + " kullanıcısı giriş yaptı! Beni hatırla durumu: " + logincheck.remember + " Tarih: " + DateTime.Now;
                    SmtpClient smtp = new SmtpClient();

                    smtp.Host = "smtp.gmail.com";

                    smtp.Port = 587;

                    smtp.Credentials = new System.Net.NetworkCredential
                    ("denemealtug@gmail.com", "");

                    smtp.EnableSsl = true;

                    smtp.Send(msz);

                    ModelState.Clear();
                    ViewBag.Message = "Başarıyla Giriş Yaptınız. İyi Eğlenceler ";
                }
                catch (Exception ex)
                {
                    ModelState.Clear();
                    ViewBag.Message = $" Bir hata oluştu! {ex.Message}";
                }
            }
            return View();
        }
        [HttpGet]
        public IActionResult Forum()
        {

            return View();
        }

        public IActionResult BlogEntry()
        {
            return View();
        }


        public IActionResult About()
        {
            ViewData["Message"] = "Dünya'nın ilk PowerShell Platformu";

            return View();
        }
        [HttpGet]
        public IActionResult Contact()
        {

            return View();
        }

        public IActionResult Tutorial()
        {


            return View();
        }
        //[HttpPost]
        //public IActionResult Tutorial(string ResultBox, string Input)
        //{
        //    if (ModelState.IsValid)
        //    {

        //        // Clean the Result TextBox
        //        ResultBox = string.Empty;

        //    // Initialize PowerShell engine
        //    var shell = PowerShell.Create();

        //    // Add the script to the PowerShell object
        //    shell.Commands.AddScript(Input);

        //    // Execute the script
        //    var results = shell.Invoke();

        //        // display results, with BaseObject converted to string
        //        // Note : use |out-string for console-like output
        //        if (results.Count > 0)
        //        {
        //            // We use a string builder ton create our result text
        //            var builder = new StringBuilder();

        //            foreach (var psObject in results)
        //            {
        //                // Convert the Base Object to a string and append it to the string builder.
        //                // Add \r\n for line breaks
        //                builder.Append(psObject.BaseObject.ToString() + "\r\n");
        //            }

        //            // Encode the string in HTML (prevent security issue with 'dangerous' caracters like < >
        //           // ResultBox = Server.HtmlEncode(builder.ToString());
        //        }

        //    }
        //    return View();
        //}

        [HttpPost]
        public IActionResult SignUp(InsertNewMemberRequest createMember)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    MailMessage msz = new MailMessage();
                    msz.From = new MailAddress(createMember.Email);//Email which you are getting 
                                                                   //from contact us page 
                    msz.To.Add("altugyildirim1993@gmail.com,hakkiogretmen@gmail.com");//Where mail will be sent 
                    msz.Subject = "Kullanıcı Girişi hk.";
                    msz.Body = createMember.Email + " kullanıcısı kayıt oldu! Tarih: " + DateTime.Now;
                    SmtpClient smtp = new SmtpClient();

                    smtp.Host = "smtp.gmail.com";

                    smtp.Port = 587;

                    smtp.Credentials = new System.Net.NetworkCredential
                    ("denemealtug@gmail.com", "");

                    smtp.EnableSsl = true;

                    smtp.Send(msz);

                    ModelState.Clear();
                    ViewBag.Message = "Kayıt olduğunuz için teşekkür ederiz. Şimdi Giriş yapabilirsiniz. ";
                }
                catch (Exception ex)
                {
                    ModelState.Clear();
                    ViewBag.Message = $" Bir hata oluştu! {ex.Message}";
                }
            }
            return View();
        }
        [HttpGet]
        public IActionResult SignUp()
        {
            return View();
        }
        
       
        public IActionResult BlogEditor()
        {
            return View();
        }

        [HttpPost]
        public IActionResult BlogEditor(Blog postData)
        {
            Blog umodel = new Blog();
            umodel.Description = HttpContext.Request.Form["Description"].ToString();
            //umodel.Id = '1';
            umodel.Title = HttpContext.Request.Form["Title"].ToString();
            umodel.PostedOn = DateTime.Now;
            umodel.PostedBy = HttpContext.Request.Form["PostedBy"].ToString();


            int result = umodel.SaveDetails();
            if (result > 0)
            {
                ViewBag.Result = "Yazmak güçtür. Yazdığınız için teşekkür ederiz!";
            }
            else
            {
                ViewBag.Result = "Hata aldık, tekrar dener misiniz?";
            }

            return View();
        }

        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
