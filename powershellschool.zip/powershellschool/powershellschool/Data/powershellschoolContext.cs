﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace powershellschool.Models
{
    public class powershellschoolContext : DbContext
    {
        public powershellschoolContext (DbContextOptions<powershellschoolContext> options)
            : base(options)
        {
        }

        public DbSet<powershellschool.Models.Blog> Blog { get; set; }
    }

}
