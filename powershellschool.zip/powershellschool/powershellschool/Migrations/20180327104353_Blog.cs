﻿using Microsoft.EntityFrameworkCore.Migrations;
using System;
using System.Collections.Generic;

namespace powershellschool.Migrations
{
    public partial class Blog : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {



            migrationBuilder.CreateTable(
            name: "Blog",
            columns: table => new
            {
                ID = table.Column<int>(nullable: true),
                Title = table.Column<string>(nullable: true),
                Description = table.Column<string>(nullable: true),
                Image = table.Column<int>(nullable: true),
                PostedBy = table.Column<string>(nullable: true),
                PostedOn = table.Column<DateTime>(nullable: true)

            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Blog", x => x.ID);
            });

            // Additional code not shown
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
