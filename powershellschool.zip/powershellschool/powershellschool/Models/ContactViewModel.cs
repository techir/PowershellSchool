﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using Microsoft.Extensions.Configuration;
using System.IO;


namespace powershellschool.Models
{
    public static class GetConString
    {
        public static string ConString()
        {
            var builder = new ConfigurationBuilder().SetBasePath(Directory.GetCurrentDirectory()).AddJsonFile("appsettings.json", optional: true, reloadOnChange: true);
            var config = builder.Build();
            string constring = config.GetConnectionString("powershellschoolContext");
            return constring;
        }
    }
    public class ContactViewModel
    {
        [Required]
        [StringLength(20, MinimumLength = 5)]
        public string Name { get; set; }
        [Required]
        [EmailAddress]
        public string Email { get; set; }
        [Required]
        public string Subject { get; set; }
        [Required]
        public string Message { get; set; }
    }

    public class Blog
    {
       
        public int Id { get; set; }
        
        public string Title { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public string PostedBy { get; set; }
        public DateTime PostedOn { get; set; }

        public int SaveDetails()
        {
            SqlConnection con = new SqlConnection(GetConString.ConString());
            string query = "INSERT INTO Blog( Title, Description,Image,PostedBy,PostedOn) values ('" + Title + "','" + Description + "','" + Image + "','" + PostedBy + "','" + PostedOn + "')";
            //string query = "INSERT INTO Blog(Description) values ('" + Description + "')";
            SqlCommand cmd = new SqlCommand(query, con);
            con.Open();
            int i = cmd.ExecuteNonQuery();
            con.Close();
            return i;
        }

    }
    public class TutorialViewModel {
        public string Input { get; set; }
        public string ResultBox { get; set; }
        


    }

    public class CheckExistingMemberLoginInfo
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        [StringLength(20, MinimumLength = 5)]
        public string Password{ get; set; }
        public bool remember{ get; set; }
    }
    public class InsertNewMemberRequest
    {
        [Required]
        public string Username { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }

        [Compare("Password", ErrorMessage = "Şifreniz uyuşmuyor, Lütfen Tekrar Deneyin !")]
        public string ConfirmPassword { get; set; }
    }
    public class subs
    {
        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }

  

}
